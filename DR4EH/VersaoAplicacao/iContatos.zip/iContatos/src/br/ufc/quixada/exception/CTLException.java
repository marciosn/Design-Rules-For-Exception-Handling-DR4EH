package br.ufc.quixada.exception;

public class CTLException extends Exception {

	private static final long serialVersionUID = 1L;

}
