package br.ufc.quixada.dao;

import java.util.List;

import br.ufc.quixada.exception.DAOException;
import br.ufc.quixada.model.Contato;

public class ContatoDAO {

	public void create(Contato contato) throws DAOException {
	}

	public Contato retrieve(Long id) throws DAOException {
		throw new DAOException();
	}

	public void update(Contato contato) throws DAOException {
		throw new DAOException();
	}

	public void delete(Long id) throws DAOException {
		throw new DAOException();
	}

	public List<Contato> list() throws DAOException {
		throw new DAOException();
	}
}
