package br.ufc.quixada.control;

import br.ufc.quixada.dao.ContatoDAO;
import br.ufc.quixada.exception.CTLException;
import br.ufc.quixada.exception.DAOException;
import br.ufc.quixada.model.Contato;

public class Controller {

	private ContatoDAO dao;

	public Controller() {
		dao = new ContatoDAO();
	}

	public void adicionar(Contato contato) throws CTLException {
		try {
			dao.create(contato);
		} catch (DAOException dao) {
			throw new CTLException();
		}
	}

	public void remover(Long id) throws CTLException {
		try {
			dao.delete(id);
		} catch (DAOException dao) {
			throw new CTLException();
		}
	}

	public void atualizar(Contato contato) throws CTLException{
		try {
			dao.update(contato);
		} catch (DAOException dao) {
			throw new CTLException();
		}
	}
}
