package br.ufc.quixada.view;

import br.ufc.quixada.control.Controller;
import br.ufc.quixada.exception.CTLException;
import br.ufc.quixada.model.Contato;

public class ContatoView {

	private Controller controller = new Controller();

	public static void main(String[] args) {
		ContatoView view = new ContatoView();
		view.adicionarContato(null);
	}

	public void adicionarContato(Contato contato) {
		try {
			controller.adicionar(contato);
		} catch (CTLException e) {
			e.printStackTrace();
		}
	}

}
